// // content.js - MasterDesk (merged: messaging + hide logout/account/security/chat-delete)
// (function () {
//     // -------------------------
//     // messaging helpers
//     // -------------------------
//     const sendToBackground = (message, cb) => {
//         if (window.chrome && chrome.runtime && chrome.runtime.sendMessage) {
//             try {
//                 chrome.runtime.sendMessage(message, (response) => {
//                     // Check for extension context issues
//                     if (chrome.runtime.lastError) {
//                         const errMsg = chrome.runtime.lastError.message || '';
//                         if (errMsg.includes('Extension context invalidated') || errMsg.includes('Could not establish connection')) {
//                             // Notify the page to ask user to refresh
//                             window.postMessage({ type: 'MASTER_TOOLS_CONTEXT_INVALIDATED' }, '*');
//                             cb && cb({ success: false, error: 'EXTENSION_RELOAD_REQUIRED' });
//                         } else {
//                             cb && cb(response || { success: false, error: errMsg });
//                         }
//                     } else {
//                         cb && cb(response || { success: false, error: 'No response' });
//                     }
//                 });
//             } catch (err) {
//                 console.warn('chrome.runtime.sendMessage error:', err);
//                 if (err.message && err.message.includes('Extension context invalidated')) {
//                     window.postMessage({ type: 'MASTER_TOOLS_CONTEXT_INVALIDATED' }, '*');
//                 }
//                 cb && cb({ success: false, error: err.message });
//             }
//         } else {
//             console.log('chrome.runtime not available in this context');
//             cb && cb({ success: false, error: 'chrome.runtime not available' });
//         }
//     };
//     const version = (() => {
//         try {
//             return chrome?.runtime?.getManifest?.().version || "unknown";
//         } catch {
//             return "unknown";
//         }
//     })();
//     // Listen for messages from the webpage
//     window.addEventListener("message", function (event) {
//         // Skip messages that aren't strictly from our window context
//         if (event.source !== window || !event.data || !event.data.type) {
//             return;
//         }

//         const payload = event.data;

//         // extension presence check
//         if (payload.type === "MASTER_TOOLS_CHECK_EXTENSION") {
//             window.postMessage(
//                 { type: "MASTER_TOOLS_EXTENSION_PRESENT", version },
//                 "*"
//             );
//             console.log("Extension presence check -> confirmed");
//             return;
//         }

//         // Extension config check
//         if (payload.type === "MASTER_TOOLS_SET_CONFIG") {
//             sendToBackground({ type: "SET_CONFIG", payload: payload.payload });
//             return;
//         }

//         // Access platform
//         if (payload.type === "MASTER_TOOLS_ACCESS_PLATFORM") {
//             window.postMessage(
//                 { type: "MASTER_TOOLS_COOKIES_STATUS", status: "Accessing platform..." },
//                 "*"
//             );

//             sendToBackground(
//                 { type: "ACCESS", payload: payload.payload },
//                 function (response) {
//                     window.postMessage(
//                         {
//                             type: "MASTER_TOOLS_PLATFORM_ACCESS_RESULT",
//                             success: response?.success || false,
//                             error: response?.error || null,
//                             tabId: response?.tabId,
//                             payload: payload.payload // Send back the payload to trigger heartbeat next
//                         },
//                         "*"
//                     );
//                 }
//             );
//             return;
//         }

//         // Start heartbeat when user accesses platform successfully
//         if (payload.type === "MASTER_TOOLS_START_HEARTBEAT") {
//             sendToBackground(
//                 { type: "START_HEARTBEAT", payload: payload.payload },
//                 function (response) {
//                     if (response?.success) {
//                         console.log("Heartbeat started for slot:", payload.payload.slotId);
//                     }
//                 }
//             );
//             return;
//         }
        
//         // Handle slot release events from website
//         if (payload.type === "MASTER_TOOLS_SLOT_RELEASED" || payload.type === "MASTER_TOOLS_SLOT_DELETED") {
//             sendToBackground(
//                 {
//                     type: "SLOT_RELEASED",
//                     payload: payload.payload
//                 }
//             );
//             return;
//         }
//     });

//     // Listen for messages from background
//     if (window.chrome && chrome.runtime && chrome.runtime.onMessage) {
//         chrome.runtime.onMessage.addListener(function (message) {
//             if (message.type === "EXTENSION_ACTIVATED") {
//                 window.postMessage({ type: "MASTER_TOOLS_EXTENSION_ACTIVATED" }, "*");
//                 console.log("Extension activated -> notified page");
//             }
//             if (message.type === "SLOT_REFRESH_REQUIRED") {
//                 window.postMessage({ type: "MASTER_TOOLS_SLOT_REFRESH_REQUIRED", slotId: message.slotId }, "*");
//                 console.log("Slot refresh required -> notified page");
//             }
//         });
//     }

//     // Announce presence immediately
//     window.postMessage({ type: "MASTER_TOOLS_EXTENSION_PRESENT" ,version}, "*");

//     // -------------------------
//     // helper to hide a node
//     // -------------------------
//     const hideNode = (el) => {
//         if (!el || el.__mt_hidden) return;
//         try {
//             el.__mt_old_display = el.style.display;
//             el.style.display = "none";
//             el.style.pointerEvents = "none";
//             el.setAttribute("data-mt-hidden", "1");
//             el.__mt_hidden = true;
//         } catch {}
//     };

//     // -------------------------
//     // platform-specific hiding
//     // -------------------------

//     (function hideChatGptProjectsSection() {
//         const hostname = window.location.hostname;
//         if (!hostname.includes("chatgpt") && !hostname.includes("openai")) return;

//         const hideProjects = () => {
//             // Find the "Projects" section wrapper
//             const projectSections = Array.from(
//                 document.querySelectorAll(".group\\/sidebar-expando-section")
//             );

//             projectSections.forEach((section) => {
//                 const heading = section.querySelector("h2.__menu-label");
//                 if (heading && heading.textContent.trim() === "Projects") {
//                     section.style.display = "none";
//                     console.log("🟢 Hidden ChatGPT Projects section");
//                 }
//             });
//         };

//         hideProjects();

//         const observer = new MutationObserver(() => hideProjects());
//         if (document.body) {
//             observer.observe(document.body, { childList: true, subtree: true });
//         } else {
//             document.addEventListener("DOMContentLoaded", () => {
//                 observer.observe(document.body, { childList: true, subtree: true });
//             });
//         }

//         setTimeout(() => observer.disconnect(), 10000);
//     })();
//     (function hideChatGptProjectsRobust() {
//         const hostname = window.location.hostname;
//         if (!hostname.includes("chatgpt") && !hostname.includes("openai"))return;
//         const MAX_ATTEMPTS = 40; // total tries (~40 * 250ms = 10s)
//         const INTERVAL_MS = 250;
//         let attempts = 0;
//         let foundCount = 0;
//         let stopped = false;

//         // helper: hide and mark a node
//         const hideNode = (el) => {
//             if (!el || el.__mt_hidden) return false;
//             try {
//                 el.__mt_old_display = el.style.display;
//                 el.style.display = "none";
//                 el.style.pointerEvents = "none";
//                 el.setAttribute("data-mt-hidden", "1");
//                 el.__mt_hidden = true;
//                 return true;
//             } catch (err) {
//                 console.warn("hideNode error:", err);
//                 return false;
//             }
//         };

//         // Helper to find elements whose visible text equals "Projects" (case-insensitive)
//         const findProjectNodesByXPath = () => {
//             // XPath: find elements with text node exactly "Projects" (trimmed)
//             const expr = `//*/text()[normalize-space(.)='Projects' or normalize-space(.)='projects']/parent::*`;
//             const xpathResult = document.evaluate(
//                 expr,
//                 document,
//                 null,
//                 XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
//                 null
//             );
//             const nodes = [];
//             for (let i = 0; i < xpathResult.snapshotLength; i++) {
//                 nodes.push(xpathResult.snapshotItem(i));
//             }
//             return nodes;
//         };

//         // Walk up to a reasonable menu-item ancestor (heuristic)
//         const nearestMenuAncestor = (el) => {
//             if (!el) return null;
//             let node = el;
//             let depth = 0;
//             while (node && depth < 6) {
//                 // walk up to 6 levels
//                 if (!node.tagName) break;
//                 const cls = (node.className || "").toString();
//                 const role = node.getAttribute && node.getAttribute("role");
//                 // heuristic: look for classes/roles commonly used for menu items / sidebar rows
//                 if (
//                     /__menu-item|group|menu-item|sidebar|nav|list|menu/i.test(
//                         cls
//                     ) ||
//                     role === "menuitem" ||
//                     role === "tab" ||
//                     role === "button"
//                 ) {
//                     return node;
//                 }
//                 node = node.parentElement;
//                 depth++;
//             }
//             return el; // fallback: hide the direct parent if nothing better found
//         };

//         const hideProjectsOnce = () => {
//             const matches = findProjectNodesByXPath();

//             const fallback = Array.from(
//                 document.querySelectorAll(
//                     ".truncate, .__menu-item, [data-testid]"
//                 )
//             ).filter((el) => {
//                 const txt = (el.textContent || "").trim().toLowerCase();
//                 return txt === "projects";
//             });

//             const all = Array.from(new Set([...matches, ...fallback]));

//             all.forEach((labelEl) => {
//                 const ancestor = nearestMenuAncestor(labelEl);
//                 if (ancestor) {
//                     const ok = hideNode(ancestor);
//                     if (ok) {
//                         foundCount++;
//                     }
//                 }
//             });

//             document.querySelectorAll("button, a").forEach((el) => {
//                 const txt = (el.textContent || "").trim().toLowerCase();
//                 if (txt.includes("add to project")) {
//                     hideNode(el);
//                 }
//             });

//             return all.length;
//         };

//         const runAttempt = () => {
//             if (stopped) return;
//             attempts++;
//             try {
//                 hideProjectsOnce();
//             } catch (err) {
//                 console.error("Master Tools hideProjectsOnce error:", err);
//             }

//             if (attempts >= MAX_ATTEMPTS) {
//                 stopAll();
//             }
//         };

//         // stop interval and observer
//         const stopAll = () => {
//             stopped = true;
//             if (observer) observer.disconnect();
//             if (intervalId) clearInterval(intervalId);
//         };

//         // Expose debug helper
//         window.__mt_debugProjects = function () {
//             const found = findProjectNodesByXPath();
//             console.log("Master Tools debug -> XPath matches:", found);
//             const fallback = Array.from(
//                 document.querySelectorAll(
//                     ".truncate, .__menu-item, [data-testid]"
//                 )
//             ).filter(
//                 (el) =>
//                     (el.textContent || "").trim().toLowerCase() === "projects"
//             );
//             console.log("Master Tools debug -> fallback matches:", fallback);
//             return { xpath: found, fallback };
//         };

//         const observer = new MutationObserver((mutations) => {
//             try {
//                 runAttempt();
//             } catch (err) {
//                 console.error("Master Tools observer error:", err);
//             }
//         });

//         let intervalId = null;
//         if (document.body) {
//             try {
//                 observer.observe(document.body, {
//                     childList: true,
//                     subtree: true,
//                 });
//             } catch (err) {
//                 console.warn("Master Tools observer.observe failed:", err);
//             }
//         } else {
//             document.addEventListener("DOMContentLoaded", () => {
//                 observer.observe(document.body, {
//                     childList: true,
//                     subtree: true,
//                 });
//             });
//         }

//         intervalId = setInterval(() => runAttempt(), INTERVAL_MS);
//         setTimeout(() => stopAll(), MAX_ATTEMPTS * INTERVAL_MS + 1000);
//         window.__mt_showHidden = function () {
//             document.querySelectorAll("[data-mt-hidden='1']").forEach((el) => {
//                 try {
//                     el.style.display = el.__mt_old_display || "";
//                     el.style.pointerEvents = "";
//                     el.removeAttribute("data-mt-hidden");
//                     el.__mt_hidden = false;
//                 } catch (err) {
//                     console.warn("showHidden error:", err);
//                 }
//             });
//         };
//         runAttempt();
//     })();


//     const hideByPlatform = () => {
//         const hostname = window.location.hostname;

//         // Udemy
//         if (hostname.includes(".udemy.com")) {
//             const selectors = [
//                 'a[href*="logout"]',
//                 '[data-purpose="user_manage:edit-api-clients"]',
//                 '[data-purpose="user_manage:close-account"]',
//                 '[class="um-mt-md api-clients--request-client-button-row--xnWfL"]',
//                 '[data-purpose="show-delete-confirm-modal"]',
//                 '[data-purpose="close-account-modal-trigger"]',
//                 '[data-purpose="user_manage:submit"]',
//                 '[data-purpose="payment-settings-group"]',
//                 '[data-purpose="update-card-button"]',
//                 '[data-purpose="retry-payment-button"]',
//                 '[data-purpose="cancel-trial-button"]',
//                 '[class="show-mfa--mfa-panel--9IbjB"]',
//                 '[data-purpose="edit-email"]',
//                 '[data-purpose="subscribe-trial-button"]',
//                 '[data-purpose="sticky-summary"]',
//                 '[data-testid="payment-method"]',
//                 '[id="subscriptionTrialOfferButton"]',
//                 '[class="app--stored-payment-method-actions--tkuuI"]',
//             ];

//             selectors.forEach((sel) =>
//                 document.querySelectorAll(sel).forEach(hideNode)
//             );

//             // Hide account-related menu items
//             document.querySelectorAll("ul.ud-unstyled-list.ud-block-list.list-menu-module--section--l6I-M").forEach((ul) => {
//                     const hideTexts = [
//                         "payment methods",
//                         "subscriptions",
//                         "udemy credits",
//                         "purchase history",
//                     ];

//                     const shouldHide = Array.from(
//                         ul.querySelectorAll("div.ud-block-list-item-content")
//                     ).some((div) =>
//                         hideTexts.includes(div.textContent.trim().toLowerCase())
//                     );

//                     if (shouldHide) hideNode(ul);});

//             document.querySelectorAll("form").forEach((form) => {
//                 if (
//                     form.action.includes("/user/edit-profile") ||
//                     form.action.includes("/user/edit-account") ||
//                     form.action.includes("/user/edit-photo") ||
//                     form.closest(".profile-form-class")
//                 ) {
//                     form.querySelectorAll("input, textarea, select").forEach(
//                         (el) => {
//                             if (!el.closest(".ud-search-bar")) {
//                                 el.disabled = true;
//                             }
//                         }
//                     );

//                     form.addEventListener(
//                         "submit",
//                         (e) => {
//                             e.preventDefault();
//                             e.stopImmediatePropagation();
//                             console.log("Profile editing blocked 🚫");
//                         },
//                         true
//                     );
//                 }
//             });
//         }

//         // ChatGPT
//         if (hostname.includes(".chatgpt.com") || hostname.includes("openai")) {
//             hideChatGptNewProject();
//             const selectors = [
//                 '[data-testid="account-tab"]',
//                 '[data-testid="security-tab"]',
//                 '[data-testid="data-controls-tab"]',
//                 '[data-testid="log-out-menu-item"]',
//                 '[data-testid="amphora-controls-tab"]',
//             ];

//             // Hide any existing matches immediately
//             selectors.forEach((sel) => {
//                 document.querySelectorAll(sel).forEach(hideNode);
//             });
//         }
//     };

//     // -------------------------
//     // optional text-based hiding (for extra coverage)
//     // -------------------------
//     const hideByTextSmart = () => {
//         const hostname = window.location.hostname;
//         if (
//             !hostname.includes(".udemy.com") &&
//             !hostname.includes("chatgpt") &&
//             !hostname.includes("openai")
//         )
//             return;

//         const candidates = document.querySelectorAll(
//             'button, a, [role="menuitem"], [role="tab"], [role="button"], div[role="menuitem"]'
//         );
//         candidates.forEach((el) => {
//             const text = (el.textContent || "").trim().toLowerCase();
//             if (!text) return;
//             if (
//                 [
//                     "log out",
//                     "logout",
//                     "sign out",
//                     "signout",
//                     "archive",
//                     "delete",
//                     "add to project",
//                     "projects",
//                     "unenroll from course",
//                     "update it on your subscriptions",
//                     "subscriptions",
//                     "start subscription",
//                     "add family member",
//                 ].includes(text)
//             ) {
//                 hideNode(el);
//             }
//             if (text.includes("unenroll from course")) {
//                 hideNode(el.closest("li"));
//             }

//             if (
//                 (text === "account" ||
//                     text === "security" ||
//                     text === "add to project" ||
//                     text === "data controls") &&
//                 el.matches(
//                     '[role="tab"], [role="menuitem"], [data-testid*="tab"], .__menu-item'
//                 )
//             ) {
//                 hideNode(el);
//             }

//             if (
//                 text.includes("delete") ||
//                 text.includes("remove") ||
//                 text.includes("archive")
//             ) {
//                 const inChat = !!el.closest(
//                     '[data-testid*="chat"], [class*="chat"], [data-testid*="history"], [aria-label*="chat"]'
//                 );
//                 const isDeleteButtonTestId =
//                     el.dataset?.testid &&
//                     el.dataset.testid.toLowerCase().includes("delete");
//                 if (inChat || isDeleteButtonTestId) hideNode(el);
//             }
//         });
//     };

//     // -------------------------
//     // scheduler to avoid thrashing
//     // -------------------------
//     let scheduled = false;
//     const scheduleHide = () => {
//         if (scheduled) return;
//         scheduled = true;
//         requestAnimationFrame(() => {
//             try {
//                 hideByPlatform();
//                 hideByTextSmart();
//             } catch (e) {
//                 console.log("hideElements error:", e);
//             }
//             scheduled = false;
//         });
//     };

//     // Run immediately
//     scheduleHide();

//     // Observe DOM mutations
//     const observer = new MutationObserver(scheduleHide);
//     try {
//         if (document.body) {
//             observer.observe(document.body, { childList: true, subtree: true });
//         } else {
//             document.addEventListener("DOMContentLoaded", () => {
//                 observer.observe(document.body, { childList: true, subtree: true });
//             });
//         }
//     } catch (e) {
//         console.warn("MutationObserver observe failed:", e);
//     }

//     // Re-run on visibility/focus changes
//     window.addEventListener("focus", scheduleHide);
//     document.addEventListener("visibilitychange", () => {
//         if (document.visibilityState === "visible") scheduleHide();
//     });

//     // Debug helper
//     window.__mt_showHidden = function () {
//         document.querySelectorAll("[data-mt-hidden='1']").forEach((el) => {
//             try {
//                 el.style.display = el.__mt_old_display || "";
//                 el.style.pointerEvents = "";
//                 el.removeAttribute("data-mt-hidden");
//                 el.__mt_hidden = false;
//             } catch {}
//         });
//     };

//     console.log(
//         "MasterDesk content script loaded (cookie bridge + platform-specific UI hiding)."
//     );
// })();

// content.js - MasterDesk (Optimized: messaging + UI hiding)
(function () {
    // -------------------------
    // 1. Messaging Helpers
    // -------------------------
    const sendToBackground = (message, cb) => {
        // Check if context is valid
        if (!chrome.runtime || !chrome.runtime.id) {
            console.warn('[MasterTools] Context invalidated. Refresh required.');
            window.postMessage({ type: 'MASTER_TOOLS_CONTEXT_INVALIDATED' }, '*');
            cb && cb({ success: false, error: 'EXTENSION_CONTEXT_INVALIDATED' });
            return;
        }

        try {
            chrome.runtime.sendMessage(message, (response) => {
                if (chrome.runtime.lastError) {
                    const errMsg = chrome.runtime.lastError.message || '';
                    if (errMsg.includes('context invalidated')) {
                        window.postMessage({ type: 'MASTER_TOOLS_CONTEXT_INVALIDATED' }, '*');
                        cb && cb({ success: false, error: 'RELOAD_REQUIRED' });
                    } else {
                        cb && cb(response || { success: false, error: errMsg });
                    }
                } else {
                    cb && cb(response || { success: false, error: 'No response' });
                }
            });
        } catch (err) {
            console.error('[MasterTools] Send error:', err);
            cb && cb({ success: false, error: err.message });
        }
    };

    const version = (() => {
        try { return chrome?.runtime?.getManifest?.().version || "unknown"; } 
        catch { return "unknown"; }
    })();

    // -------------------------
    // 2. Webpage Message Listener
    // -------------------------
    window.addEventListener("message", function (event) {
        if (event.source !== window || !event.data || !event.data.type) return;

        const payload = event.data;

        switch (payload.type) {
            case "MASTER_TOOLS_CHECK_EXTENSION":
                window.postMessage({ type: "MASTER_TOOLS_EXTENSION_PRESENT", version }, "*");
                break;

            case "MASTER_TOOLS_SET_CONFIG":
                sendToBackground({ type: "SET_CONFIG", payload: payload.payload });
                break;

            case "MASTER_TOOLS_ACCESS_PLATFORM":
                window.postMessage({ type: "MASTER_TOOLS_COOKIES_STATUS", status: "Accessing platform..." }, "*");
                sendToBackground({ type: "ACCESS", payload: payload.payload }, (res) => {
                    console.log("[MasterTools Content] ACCESS response:", res); // Debug log
                    
                    // Save active slot context in case we need to terminate during close/unload
                    if (res?.success) {
                       window.__mt_active_slot_id = payload.payload.slotId;
                       window.__mt_active_slot_token = payload.payload.token;
                       // We must also extract the environment base URL the website is using 
                       // Either passed via payload.apiUrl or we assume based on the dashboard host
                       window.__mt_api_base_url = payload.payload.apiUrl || 
                          (window.location.hostname === "localhost" ? "http://localhost:8080" : "https://api.masterdesk.xyz");
                    }

                    window.postMessage({
                        type: "MASTER_TOOLS_PLATFORM_ACCESS_RESULT",
                        success: res?.success || false,
                        error: res?.error || null,
                        tabId: res?.tabId, // Ensure tabId is passed back
                        payload: payload.payload
                    }, "*");
                });
                break;

            case "MASTER_TOOLS_START_HEARTBEAT":
                sendToBackground({ type: "START_HEARTBEAT", payload: payload.payload });
                break;

            case "MASTER_TOOLS_SLOT_RELEASED":
            case "MASTER_TOOLS_SLOT_DELETED":
                sendToBackground({ type: "SLOT_RELEASED", payload: payload.payload });
                break;

            case "MASTER_TOOLS_CHECK_BAD_EXTENSIONS":
                sendToBackground({ type: "CHECK_BAD_EXTENSIONS" }, (res) => {
                    window.postMessage({
                        type: "MASTER_TOOLS_BAD_EXTENSIONS_RESULT",
                        hasBadExtensions: res?.hasBadExtensions || false
                    }, "*");
                });
                break;
                
            case "MASTER_TOOLS_CLEANUP_AND_EXIT":
                sendToBackground({ type: "CLEANUP_AND_EXIT" });
                break;
        }
    });

    // Listen for messages from background
    if (window.chrome && chrome.runtime && chrome.runtime.onMessage) {
        chrome.runtime.onMessage.addListener((message) => {
            if (message.type === "EXTENSION_ACTIVATED") {
                window.postMessage({ type: "MASTER_TOOLS_EXTENSION_ACTIVATED" }, "*");
            }
            if (message.type === "SLOT_REFRESH_REQUIRED") {
                window.postMessage({ type: "MASTER_TOOLS_SLOT_REFRESH_REQUIRED", slotId: message.slotId }, "*");
            }
        });
    }

    // Announce presence
    window.postMessage({ type: "MASTER_TOOLS_EXTENSION_PRESENT", version }, "*");

    // -------------------------
    // 3. UI Hiding Logic
    // -------------------------
    const hideNode = (el) => {
        if (!el || el.__mt_hidden) return;
        try {
            el.__mt_old_display = el.style.display;
            el.style.setProperty("display", "none", "important");
            el.style.pointerEvents = "none";
            el.setAttribute("data-mt-hidden", "1");
            el.__mt_hidden = true;
        } catch {}
    };

    const hideByPlatform = () => {
        const host = window.location.hostname;

        // --- Udemy Hiding ---
        if (host.includes("udemy.com")) {
            const udemySelectors = [
                'a[href*="logout"]', '[data-purpose*="close-account"]', 
                '[data-purpose*="payment-settings"]', '[data-purpose*="mfa-panel"]',
                '#subscriptionTrialOfferButton', '[data-purpose*="edit-profile"]'
            ];
            udemySelectors.forEach(s => document.querySelectorAll(s).forEach(hideNode));
        }

        // --- ChatGPT Hiding ---
        if (host.includes("chatgpt.com") || host.includes("openai.com")) {
            const gptSelectors = [
                '[data-testid="account-tab"]', '[data-testid="security-tab"]',
                '[data-testid="data-controls-tab"]', '[data-testid="log-out-menu-item"]',
                'nav a[href="/admin"]', // Example for workspace admin
            ];
            gptSelectors.forEach(s => document.querySelectorAll(s).forEach(hideNode));

            // Hide "Projects" from Sidebar specifically
            const navLinks = document.querySelectorAll('nav a, nav div');
            navLinks.forEach(el => {
                if (el.textContent.trim().toLowerCase() === 'projects') {
                    const container = el.closest('li') || el.closest('.group');
                    hideNode(container);
                }
            });
        }
    };

    const hideByTextSmart = () => {
        const forbiddenTexts = [
            "log out", "logout", "sign out", "signout", "delete account",
            "archive chat", "delete chat", "unenroll", "subscriptions", "payment methods"
        ];

        const elements = document.querySelectorAll('button, a, [role="menuitem"], span');
        elements.forEach(el => {
            const txt = el.textContent?.trim().toLowerCase();
            if (forbiddenTexts.includes(txt)) {
                // Additional check for chat history to avoid hiding normal text
                const isChatHistory = el.closest('[data-testid*="history"]') || el.closest('nav');
                if (isChatHistory || el.tagName === 'A' || el.tagName === 'BUTTON') {
                    hideNode(el);
                }
            }
        });
    };

    // -------------------------
    // 4. Execution & Observation
    // -------------------------
    let lock = false;
    const runHider = () => {
        if (lock) return;
        lock = true;
        
        // Wrap in try-catch to handle "Extension context invalidated"
        try {
            hideByPlatform();
            hideByTextSmart();
        } catch (e) {
            // If context is dead, stop observing
            if (e.message.includes("Extension context invalidated")) {
                observer.disconnect();
            }
        }
        
        setTimeout(() => { lock = false; }, 100);
    };

    const observer = new MutationObserver(runHider);
    if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
        runHider();
    } else {
        document.addEventListener("DOMContentLoaded", () => {
            observer.observe(document.body, { childList: true, subtree: true });
            runHider();
        });
    }

    // Debug tool to reveal hidden elements
    window.__mt_reveal = () => {
        document.querySelectorAll("[data-mt-hidden='1']").forEach(el => {
            el.style.display = el.__mt_old_display || "";
            el.__mt_hidden = false;
        });
        console.log("MasterTools: Hidden elements revealed.");
    };

    // -------------------------
    // 5. Force Auto-Close on Extension Removal & Data Wipe
    // -------------------------
    const wipeDataAndClose = () => {
        try {
            console.log("[MasterTools] Extension context lost. Wiping data & closing tab.");
            // Wipe Storage
            localStorage.clear();
            sessionStorage.clear();
            
            // Wipe Cookies aggressively
            const cookies = document.cookie.split(";");
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i];
                const eqPos = cookie.indexOf("=");
                const name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
                const domain = window.location.hostname;
                const baseDomain = domain.replace(/^www\./, "").replace(/^\./, "");
                
                // Overwrite with empty value and past expiry on multiple domain variations
                document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/";
                document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=" + domain;
                document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=." + domain;
                document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=" + baseDomain;
                document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/;domain=." + baseDomain;
            }
        } catch(e) { console.error(e); }
        
        // Force close
        window.close();
        
        // Fallback UI destruction if close is blocked by browser
        setTimeout(() => {
            document.documentElement.innerHTML = "";
            document.body.innerHTML = "<div style='display:flex;justify-content:center;align-items:center;height:100vh;background:white;color:black;font-family:sans-serif;font-size:24px;'>Session Expired. Please close this tab.</div>";
        }, 500);
    };

    setInterval(() => {
        // If the context is dead, extension is disabled/removed
        if (!chrome.runtime || !chrome.runtime.id) {
            wipeDataAndClose();
            return;
        }

        try {
            chrome.runtime.sendMessage({ type: "PING_KEEPALIVE" }, () => {
                if (chrome.runtime.lastError) {
                    const msg = chrome.runtime.lastError.message || "";
                    if (msg.includes("context invalidated") || msg.includes("connection")) {
                        wipeDataAndClose();
                    }
                }
            });
        } catch (e) {
            if (e.message && e.message.includes("context invalidated")) {
                wipeDataAndClose();
            }
        }
    }, 1500);

    console.log(`MasterDesk Tools v${version} Active.`);
})();