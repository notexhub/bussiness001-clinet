#!/bin/bash

# ============================================================
# MasterDesk — API curl commands
# ============================================================
# Usage:
#   1. Set your TOKEN and SLOT_ID below (or export them beforehand).
#   2. chmod +x api_tests.sh
#   3. ./api_tests.sh
# ============================================================

BASE_URL="https://api.masterdesk.xyz"

# ── Replace these with real values before running ────────────
TOKEN="${TOKEN:-your_bearer_token_here}"
SLOT_ID="${SLOT_ID:-your_slot_id_here}"
PLATFORM="${PLATFORM:-chatgpt}"    # e.g. chatgpt, udemy, canva, etc.
# ─────────────────────────────────────────────────────────────

echo "============================================"
echo "  MasterDesk — API Tests"
echo "  Base URL : $BASE_URL"
echo "  Token    : ${TOKEN:0:20}..."
echo "  Slot ID  : $SLOT_ID"
echo "  Platform : $PLATFORM"
echo "============================================"
echo ""

# ----------------------------------------------------------
# 1. GET  /api/slots/:slotId/status
#    Check whether a slot is currently active.
#    Returns: { isActive, domain, slotId, platformId, ... }
# ----------------------------------------------------------
echo "──────────────────────────────────────────"
echo "1) GET /api/slots/$SLOT_ID/status"
echo "   Check slot active status"
echo "──────────────────────────────────────────"

curl -s -w "\nHTTP Status: %{http_code}\n" \
  -X GET \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  "$BASE_URL/api/slots/$SLOT_ID/status"

echo ""
echo ""

# ----------------------------------------------------------
# 2. PATCH  /api/slots/:slotId/heartbeat
#    Send a heartbeat ping to keep the slot alive.
#    Called every 1 minute by the extension.
#    200 = success, 400 = user not using slot,
#    401 = auth failed, 404 = slot not found
# ----------------------------------------------------------
echo "──────────────────────────────────────────"
echo "2) PATCH /api/slots/$SLOT_ID/heartbeat"
echo "   Send heartbeat (keep slot alive)"
echo "──────────────────────────────────────────"

curl -s -w "\nHTTP Status: %{http_code}\n" \
  -X PATCH \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  "$BASE_URL/api/slots/$SLOT_ID/heartbeat"

echo ""
echo ""

# ----------------------------------------------------------
# 3. GET  /api/cookies/latest?platform=<platform>
#    Fetch the latest cookie data for a platform.
#    Returns: { domain, redirect, cookies: [...] }
# ----------------------------------------------------------
echo "──────────────────────────────────────────"
echo "3) GET /api/cookies/latest?platform=$PLATFORM"
echo "   Fetch platform cookie data"
echo "──────────────────────────────────────────"

curl -s -w "\nHTTP Status: %{http_code}\n" \
  -X GET \
  -H "Authorization: Bearer $TOKEN" \
  "$BASE_URL/api/cookies/latest?platform=$PLATFORM"

echo ""
echo ""
echo "============================================"
echo "  Done."
echo "============================================"
