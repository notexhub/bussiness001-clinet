// let API_BASE_URL = "https://api.masterdesk.xyz";
let API_BASE_URL = "https://api.masterdesk.xyz";
let activeHeartbeats = new Map();
let tabToSlot = new Map();
let dashboardToToolTabs = new Map();
let openWindowsCount = 1; // Default to 1, will accurately sync soon

// Sync initial window count immediately
try {
    chrome.windows.getAll((wins) => {
        openWindowsCount = wins ? wins.length : 1;
    });
} catch(e){}

chrome.windows.onCreated.addListener(() => { openWindowsCount++; });

const STORAGE_HEARTBEATS = "active_heartbeats_state";

initialize();

async function initialize() {
    console.log("[MasterTools] Initializing background script...");
    await loadState();
}

let initPromise = initialize();

async function saveState() {
    try {
        const data = {};
        activeHeartbeats.forEach((val, key) => {
            data[key] = {
                domain: val.domain,
                token: val.token,
                tabId: val.tabId
            };
        });
        await chrome.storage.local.set({ [STORAGE_HEARTBEATS]: data });
        console.log("[MasterTools] State saved to storage.");
    } catch (e) {
        console.error("[MasterTools] Failed to save state:", e);
    }
}

async function loadState() {
    try {
        const result = await chrome.storage.local.get([STORAGE_HEARTBEATS, "managed_domains"]);
        const saved = result[STORAGE_HEARTBEATS] || {};
        
        for (const [slotId, data] of Object.entries(saved)) {
            if (data.tabId) {
                try {
                    await chrome.tabs.get(Number(data.tabId));
                    activeHeartbeats.set(slotId, { ...data, interval: null });
                    tabToSlot.set(Number(data.tabId), slotId);
                    
                    const alarmName = `heartbeat-${slotId}`;
                    const alarm = await chrome.alarms.get(alarmName);
                    if (!alarm) {
                        chrome.alarms.create(alarmName, { periodInMinutes: 2 });
                    }
                } catch (err) {
                    console.log(`[MasterTools] Ghost session detected for slot ${slotId}, clearing cookies!`);
                    if (data.domain) await clearCookiesForDomain(data.domain);
                    fetch(`${API_BASE_URL}/slots/${slotId}/release`, {
                        method: "POST",
                        headers: { "Authorization": `Bearer ${data.token}`, "Content-Type": "application/json" }
                    }).catch(()=>{});
                    delete saved[slotId];
                }
            }
        }
        
        await chrome.storage.local.set({ [STORAGE_HEARTBEATS]: saved });
        console.log(`[MasterTools] State loaded: ${activeHeartbeats.size} active heartbeats.`);
    } catch (e) {
        console.error("[MasterTools] Failed to load state:", e);
    }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("[MasterTools] Received message:", message.type);

    initPromise.then(() => {
        if (message.type === "SET_CONFIG") {
        if (message.payload.apiUrl) {
            API_BASE_URL = message.payload.apiUrl;
            console.log("[MasterTools] API URL updated to:", API_BASE_URL);
        }
        sendResponse({ success: true });
        return true;
    }

    if (message.type === "ACCESS") {
        if (message.payload && message.payload.cookies && message.payload.cookies.length > 0) {
            processPlatformData(message.payload, sendResponse, sender);
        } else {
            sendResponse({ success: false, error: "Empty or invalid cookie payload received." });
        }
        return true;
    }

    if (message.type === "START_HEARTBEAT") {
        const { slotId, token, domain, tabId } = message.payload;
        if (slotId && token) {
            startHeartbeat(slotId, token, domain, tabId);
            sendResponse({ success: true });
        } else {
            sendResponse({ success: false, error: "Missing Slot ID or Token" });
        }
        return true;
    }

        if (message.type === "SLOT_RELEASED" || message.type === "SLOT_DELETED") {
            const { slotId } = message.payload;
            releaseSlotLocally(slotId);
            sendResponse({ success: true });
        }

        if (message.type === "CLEANUP_AND_EXIT") {
            console.log("[MasterTools] Received manual CLEANUP command. Initiating wipe.");
            
            // Release all active slots first
            for (const [sId, data] of activeHeartbeats.entries()) {
                fetch(`${API_BASE_URL}/slots/${sId}/release`, {
                    method: "POST",
                    headers: { "Authorization": `Bearer ${data.token}`, "Content-Type": "application/json" }
                }).catch(()=>{});
            }

            // Close all tool tabs
            const toolTabsToClose = Array.from(tabToSlot.keys()).map(id => Number(id));
            if (toolTabsToClose.length > 0) {
                chrome.tabs.remove(toolTabsToClose).catch(()=>{});
            }

            // Wipe all cookies completely
            chrome.browsingData.remove({}, { "cookies": true }, () => {
                console.log("[MasterTools] Manual browsingData wipe complete.");
                activeHeartbeats.clear();
                tabToSlot.clear();
                dashboardToToolTabs.clear();
                chrome.storage.local.set({ [STORAGE_HEARTBEATS]: {} });
                
                sendResponse({ success: true });
                
                // Forcibly close the dashboard tab that sent this message
                if (sender && sender.tab && sender.tab.id) {
                    setTimeout(() => {
                        chrome.tabs.remove(sender.tab.id).catch(()=>{});
                    }, 500); // 500ms delay to allow the frontend toast or success logic to finish momentarily
                }
            });
            return true;
        }

        if (message.type === "CHECK_BAD_EXTENSIONS") {
            try {
                chrome.management.getAll((extensions) => {
                    const badKeywords = ["cookie", "download", "editor", "editthiscookie"];
                    const badExtensions = extensions.filter(ext => {
                        if (ext.id === chrome.runtime.id) return false;
                        if (!ext.enabled) return false;
                        
                        const name = ext.name.toLowerCase();
                        const desc = (ext.description || "").toLowerCase();
                        
                        return badKeywords.some(keyword => name.includes(keyword) || desc.includes(keyword));
                    });
                    
                    if (badExtensions.length > 0) {
                        console.log("[MasterTools] WARNING: Conflicting extensions found:", badExtensions.map(e => e.name));
                        sendResponse({ hasBadExtensions: true, count: badExtensions.length });
                    } else {
                        sendResponse({ hasBadExtensions: false });
                    }
                });
            } catch (err) {
                console.error("[MasterTools] Failed to check management API:", err);
                sendResponse({ hasBadExtensions: false });
            }
            return true; 
        }
    });

    return true; 
});

async function processPlatformData(data, sendResponse, sender) {
    try {
        const { domain, redirect, redirectUrl, cookies, slotId, token } = data;
        const targetUrl = redirect || redirectUrl;

        console.log(`[MasterTools] Processing ACCESS for ${domain} (Slot: ${slotId})`);

        const cookiePromises = cookies.map((cookie) => {
            const baseDomain = (cookie.domain || domain || "").replace(/^\./, "");
            const cookieUrl = `https://${baseDomain}${cookie.path || "/"}`;

            const cookieDetails = {
                url: cookieUrl,
                name: cookie.name,
                value: String(cookie.value || ""),
                path: cookie.path || "/",
                secure: cookie.secure !== undefined ? cookie.secure : true,
                httpOnly: cookie.httpOnly || false,
                sameSite: cookie.sameSite || "no_restriction",
            };

            if (cookie.domain) cookieDetails.domain = cookie.domain;
            // Force all cookies to be Session Cookies - Chrome deletes them natively on close
            // if (cookie.expirationDate) cookieDetails.expirationDate = cookie.expirationDate;

            return chrome.cookies.set(cookieDetails).catch((err) => {
                console.warn(`[MasterTools] Skipped invalid cookie ${cookie.name}:`, err);
                return null;
            });
        });

        await Promise.all(cookiePromises);

        let tab;
        try {
            tab = await chrome.tabs.create({ url: targetUrl || `https://${domain}`, active: true });
        } catch (tabErr) {
            console.warn("[MasterTools] chrome.tabs.create failed, trying fallback:", tabErr);
            tab = await new Promise((resolve, reject) => {
                chrome.tabs.create({ url: targetUrl || `https://${domain}` }, (newTab) => {
                    if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
                    else resolve(newTab);
                });
            });
        }

        if (slotId && tab && tab.id) {
            const tId = Number(tab.id);
            const sIdStr = String(slotId);
            tabToSlot.set(tId, sIdStr);
            console.log(`[MasterTools] Instant Map: Tab ${tId} -> Slot ${sIdStr} (during ACCESS)`);

            if (sender && sender.tab && sender.tab.id) {
                const dashTabId = sender.tab.id;
                if (!dashboardToToolTabs.has(dashTabId)) {
                    dashboardToToolTabs.set(dashTabId, new Set());
                }
                dashboardToToolTabs.get(dashTabId).add(tId);
                console.log(`[MasterTools] Mapped Dashboard Tab ${dashTabId} to Tool Tab ${tId}`);
            }

            if (!activeHeartbeats.has(sIdStr)) {
                activeHeartbeats.set(sIdStr, { domain, token, tabId: tId, interval: null });
                
                chrome.storage.local.get(["managed_domains"], (res) => {
                    const doms = new Set(res.managed_domains || []);
                    if (!doms.has(domain)) {
                        doms.add(domain);
                        chrome.storage.local.set({ managed_domains: Array.from(doms) });
                    }
                });
            }
        }

        sendResponse({ success: true, tabId: tab ? tab.id : null });
    } catch (error) {
        console.error("[MasterTools] Failed processing platform data:", error);
        sendResponse({ success: false, error: error.message });
    }
}

async function clearCookiesForDomain(domain) {
    return new Promise((resolve) => {
        const baseDomain = domain.replace(/^www\./, "").replace(/^\./, "");

        chrome.cookies.getAll({}, function (cookies) {
            const relevantCookies = cookies.filter((c) => c.domain.includes(baseDomain));
            
            if (relevantCookies.length === 0) {
                return resolve(true);
            }

            let clearedCount = 0;
            relevantCookies.forEach((cookie) => {
                const cleanDomain = cookie.domain.startsWith(".") ? cookie.domain.substring(1) : cookie.domain;
                
                // Aggressively attempt to delete with both HTTP, HTTPS and subdomain combos
                // Since chrome.cookies.remove acts silently if it fails, blasting all combinations ensures it dies.
                const urls = [
                    `https://${cleanDomain}${cookie.path}`,
                    `http://${cleanDomain}${cookie.path}`,
                    `https://.${cleanDomain}${cookie.path}`,
                    `https://www.${cleanDomain}${cookie.path}`
                ];
                
                urls.forEach(u => chrome.cookies.remove({ url: u, name: cookie.name }).catch(()=>{}));
                
                clearedCount++;
                if (clearedCount === relevantCookies.length) {
                    setTimeout(() => resolve(true), 100); // 100ms grace period for internal removal completion
                }
            });
        });
    });
}

async function sendHeartbeat(slotId, token) {
    try {
        const response = await fetch(`${API_BASE_URL}/slots/${slotId}/heartbeat`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`,
            },
        });

        const data = await response.json();
        return { success: response.ok, status: data.status, message: data.message };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

function startHeartbeat(rawSlotId, token, domain, tabId) {
    const slotId = String(rawSlotId);
    const tId = tabId ? Number(tabId) : null;

    console.log(`[MasterTools] Starting heartbeat for slot: ${slotId} (Tab: ${tId})`);

    sendHeartbeat(slotId, token);

    const alarmName = `heartbeat-${slotId}`;
    chrome.alarms.create(alarmName, { periodInMinutes: 2 });

    activeHeartbeats.set(slotId, { domain, token, tabId: tId });
    if (tId) {
        tabToSlot.set(tId, slotId);
    }
    
    saveState();
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
    await initPromise;
    if (alarm.name.startsWith("heartbeat-")) {
        const slotId = alarm.name.replace("heartbeat-", "");
        const data = activeHeartbeats.get(slotId);
        
        if (data) {
            console.log(`[MasterTools] Alarm trigger: heartbeat for ${slotId}`);
            const result = await sendHeartbeat(slotId, data.token);

            // Only release if the backend explicitly returned a success response
            // indicating the slot is no longer active. Ignore network failures.
            if (result.success && result.status !== "active") {
                console.log(`[MasterTools] Slot ${slotId} no longer active via alarm, releasing.`);
                releaseSlotLocally(slotId);
            } else if (!result.success) {
                console.warn(`[MasterTools] Heartbeat network failure for ${slotId}, keeping slot active.`);
            }
        } else {
            chrome.alarms.clear(alarm.name);
        }
    }
});

async function releaseSlotLocally(rawSlotId) {
    await initPromise;
    const slotId = String(rawSlotId);
    const data = activeHeartbeats.get(slotId);
    
    if (!data) {
        console.log(`[MasterTools] No data found for slot ${slotId}`);
        return;
    }

    const { domain, token, tabId } = data;
    
    chrome.alarms.clear(`heartbeat-${slotId}`);
    activeHeartbeats.delete(slotId);
    if (tabId) tabToSlot.delete(Number(tabId));
    saveState();

    console.log(`[MasterTools] Starting release process for Slot: ${slotId}`);

    // Fire the release request immediately using keepalive so it survives browser/tab closures
    const releasePromise = fetch(`${API_BASE_URL}/slots/${slotId}/release`, {
        method: "POST",
        headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json"
        },
        keepalive: true
    }).catch(e => console.warn("[MasterTools] Backend release notification failed:", e));

    try {
        if (domain) {
            // Do not block the initial fetch, clear cookies concurrently
            await clearCookiesForDomain(domain).catch(() => {});
        }

        const response = await releasePromise;
        if (response && response.ok) {
            console.log(`[MasterTools] Backend released successfully for ${slotId}`);
        }
    } catch (e) {
        console.warn("[MasterTools] Release error:", e);
    }

    notifyReactApp(slotId);
}

function notifyReactApp(slotId) {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach((tab) => {
            const isTargetPage = tab.url && (
                tab.url.includes("localhost") || 
                tab.url.includes("127.0.0.1") || 
                tab.url.includes("masterdesk.xyz")
            );

            if (isTargetPage) {
                console.log(`[MasterTools] 🟢 Found Target Page (${tab.id}): ${tab.url}`);
                console.log(`[MasterTools] 📤 Sending SLOT_REFRESH_REQUIRED for slotId: ${slotId}`);
                
                chrome.tabs.sendMessage(tab.id, { type: "SLOT_REFRESH_REQUIRED", slotId })
                    .then(() => console.log(`[MasterTools] ✅ Message sent to Tab ${tab.id} successfully.`))
                    .catch((err) => console.log(`[MasterTools] ⚠️ Content script message failed for Tab ${tab.id}:`, err));
            }
        });
    });
}

chrome.runtime.onStartup.addListener(async () => {
    console.log("[MasterTools] Browser startup, NUKING ALL COOKIES AND RELEASING GHOST SLOTS...");
    
    // 1. Guaranteed Total Wipe of all cookies using browsingData API
    chrome.browsingData.remove({}, { "cookies": true }, () => {
        console.log("[MasterTools] All ghost cookies instantly annihilated upon startup.");
    });

    // 2. Release any slots left over from the previous session 
    try {
        const result = await chrome.storage.local.get([STORAGE_HEARTBEATS]);
        const saved = result[STORAGE_HEARTBEATS] || {};
        for (const [slotId, data] of Object.entries(saved)) {
            console.log(`[MasterTools] Startup ghost cleanup for slot ${slotId}`);
            fetch(`${API_BASE_URL}/slots/${slotId}/release`, {
                method: "POST",
                headers: { "Authorization": `Bearer ${data.token}`, "Content-Type": "application/json" }
            }).catch(()=>{});
        }
        await chrome.storage.local.set({ [STORAGE_HEARTBEATS]: {} });
    } catch(e) {
        console.error("[MasterTools] Startup cleanup error:", e);
    }

    initialize();
});

chrome.runtime.onInstalled.addListener(() => {
    console.log("[MasterTools] Extension installed/updated, initializing state...");
    initialize();
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
    console.log(`[MasterTools] ❌ onRemoved triggered for TabId: ${tabId}`);
    await initPromise;

    // We check ALL tabs to see if any MasterDesk dashboard remains
    // CRITICAL: We exclude the tabId that is currently being removed!
    const allTabs = await chrome.tabs.query({});
    const dashboardTabs = allTabs.filter(t => {
        try {
            if (t.id === tabId) return false; 
            if (!t.url) return false;
            const url = t.url.toLowerCase();
            return url.includes("masterdesk.xyz") || url.includes("localhost") || url.includes("127.0.0.1");
        } catch(e) { return false; }
    });

    console.log(`[MasterTools] Active Dashboard Tabs remaining: ${dashboardTabs.length}`);

    if (dashboardTabs.length === 0) {
        console.log("[MasterTools] CRITICAL: No dashboard tabs left. Starting cleanup...");
        
        // 1. Release slots on backend
        for (const [sId, data] of activeHeartbeats.entries()) {
            try {
                console.log(`[MasterTools] Releasing slot ${sId} via Nuke`);
                fetch(`${API_BASE_URL}/slots/${sId}/release`, {
                    method: "POST",
                    headers: { "Authorization": `Bearer ${data.token}`, "Content-Type": "application/json" },
                    keepalive: true
                }).catch(e => console.warn(`[MasterTools] Nuke release failed for ${sId}:`, e));
            } catch(e) {
                console.error(`[MasterTools] Synchronous fetch crash for slot ${sId}:`, e);
            }
        }

        // 2 & 3: Clear ALL cookies first, THEN close the tool tabs!
        chrome.browsingData.remove({}, { "cookies": true }, () => {
            console.log("[MasterTools] BrowsingData API successfully wiped all cookies!");

            // Close all active tool tabs after cookies are destroyed
            const toolTabsToClose = Array.from(tabToSlot.keys()).map(id => Number(id));
            if (toolTabsToClose.length > 0) {
                console.log(`[MasterTools] Closing ${toolTabsToClose.length} tool tabs after cookie wipe!`, toolTabsToClose);
                chrome.tabs.remove(toolTabsToClose).catch(e => console.warn("[MasterTools] Failed to close some tool tabs:", e));
            }

            // Reset internal maps
            activeHeartbeats.clear();
            tabToSlot.clear();
            dashboardToToolTabs.clear();
            saveState();
        });
    }

    // Also handle individual tool tab closure mapping
    const slotId = tabToSlot.get(Number(tabId));
    if (slotId) {
        console.log(`[MasterTools] Indivdual tool tab ${tabId} closed. Releasing slot ${slotId}`);
        releaseSlotLocally(slotId);
        
        // Cleanup tracking maps
        for (const [dashId, toolTabs] of dashboardToToolTabs.entries()) {
            if (toolTabs.has(tabId)) {
                toolTabs.delete(tabId);
                if (toolTabs.size === 0) dashboardToToolTabs.delete(dashId);
            }
        }
    }
});

chrome.windows.onRemoved.addListener((windowId) => {
    openWindowsCount = Math.max(0, openWindowsCount - 1);
    console.log(`[MasterTools] ❌ Window closed. Remaining windows tracked: ${openWindowsCount}`);
    
    // SYNCHRONOUS CHECK - no await/promises before launching remove! 
    // This is critical so OS doesn't kill the background script before we fire the command.
    if (openWindowsCount === 0) {
        console.log("[MasterTools] LAST WINDOW CLOSED. INSTANT NUKING COOKIES AND SLOTS.");

        // 1. Wipe every single cookie instantly via BrowsingData (no promises)
        chrome.browsingData.remove({}, { "cookies": true }, () => {
            console.log("[MasterTools] All cookies destroyed on window close.");
        });

        // 2. Release all active slots on backend (keepalive true ensures it fires natively)
        for (const [sId, data] of activeHeartbeats.entries()) {
            try {
                fetch(`${API_BASE_URL}/slots/${sId}/release`, {
                    method: "POST",
                    headers: { "Authorization": `Bearer ${data.token}`, "Content-Type": "application/json" },
                    keepalive: true
                }).catch(()=>{});
            } catch(e){}
        }

        // 3. Reset local states synchronously
        activeHeartbeats.clear();
        tabToSlot.clear();
        dashboardToToolTabs.clear();
        chrome.storage.local.set({ [STORAGE_HEARTBEATS]: {} }).catch(()=>{});

        // 4. SYNCHRONOUS DELAY TO FORCE CHROME TO WAIT FOR CLEARING
        // Forces a 500ms delay in the background thread. Usually the OS kills extensions 
        // almost instantly on close. This completely freezes the thread giving the async 
        // browsingData.remove enough time to be processed by Chrome's native engine!
        const start = Date.now();
        while (Date.now() - start < 500) {
            // Block thread intentionally to delay shutdown
        }
    }
});




chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    await initPromise;
    const sId = Number(tabId);
    
    // ======== GHOST NAVIGATION GUARD ========
    // If Chrome restored a session after the Browser 'X' was clicked, 
    // it will try to reload the tool tab. This intercepts it and destroys the cookies!
    if (tab.url) {
        const targetUrl = tab.url.toLowerCase();
        chrome.storage.local.get(["managed_domains"], (res) => {
            const managed = res.managed_domains || [];
            
            for (const dom of managed) {
                const baseDom = dom.replace(/^www\./, "").replace(/^\./, "").toLowerCase();
                
                if (targetUrl.includes(baseDom)) {
                    let hasActiveSlot = false;
                    for (const [_, data] of activeHeartbeats.entries()) {
                        if (data.domain && data.domain.toLowerCase().includes(baseDom)) {
                            hasActiveSlot = true;
                            break;
                        }
                    }
                    
                    // If no active slot exists for this domain, it's a restored unauthorized ghost session!
                    // E.g., user clicked Browser X, Chrome kept cookies, user restarted Chrome.
                    if (!hasActiveSlot && !targetUrl.includes("masterdesk.xyz")) {
                        console.log(`[MasterTools] 🚫 GHOST NAVIGATION GUARD triggered for ${baseDom}! Wiping cookies & redirecting.`);
                        clearCookiesForDomain(baseDom);
                        try {
                            chrome.tabs.update(tabId, { url: "https://masterdesk.xyz/" }).catch(()=>{});
                        } catch(e){}
                    }
                }
            }
        });
    }
    // ==========================================

    if (changeInfo.status === 'complete' && tabToSlot.has(sId)) {
        chrome.scripting.executeScript({
            target: { tabId: sId },
            func: () => {
                if (window.__md_managed) return;
                window.__md_managed = true;
                setInterval(() => {
                    try {
                        chrome.runtime.sendMessage({ping: 'keepalive'}, () => {
                            if (chrome.runtime.lastError && chrome.runtime.lastError.message.includes('context invalidated')) {
                                window.close();
                            }
                        });
                    } catch(e) {
                        if (e.message.includes('context invalidated')) {
                            window.close();
                        }
                    }
                }, 1500);
            }
        }).catch(err => console.log('[MasterTools] executeScript error:', err));
    }
});

// Extension Policy Enforcement: Prevent Cookie Editors
function isCookieEditorExtension(ext) {
    if (ext.id === chrome.runtime.id) return false;
    const name = ext.name.toLowerCase();
    const desc = (ext.description || "").toLowerCase();
    
    // Direct matches / keyword presence
    if (name.includes("editthiscookie")) return true;
    if (name.includes("cookie") && name.includes("edit")) return true;
    if (desc.includes("cookie") && desc.includes("editor")) return true;
    
    return false;
}

function enforceExtensionPolicy() {
    if (!chrome.management) return;
    chrome.management.getAll((extensions) => {
        extensions.forEach(ext => {
            if (isCookieEditorExtension(ext) && ext.enabled) {
                console.log(`[MasterTools] Conflicting extension detected: ${ext.name}. Disabling...`);
                chrome.management.setEnabled(ext.id, false);
            }
        });
    });
}

// Also listen for new installations or re-enabling
if (chrome.management && chrome.management.onInstalled) {
    chrome.management.onInstalled.addListener((ext) => {
        if (isCookieEditorExtension(ext)) {
            console.log(`[MasterTools] New conflicting extension installed: ${ext.name}. Disabling...`);
            chrome.management.setEnabled(ext.id, false);
        }
    });

    chrome.management.onEnabled.addListener((ext) => {
        if (isCookieEditorExtension(ext)) {
            console.log(`[MasterTools] Conflicting extension enabled: ${ext.name}. Disabling...`);
            chrome.management.setEnabled(ext.id, false);
        }
    });
}

// Call initially
enforceExtensionPolicy();