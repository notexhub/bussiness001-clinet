# MasterDesk Access — Browser Extension

> Easily access premium platforms with automatic cookie management and session tracking.

**Version:** 2.0.0  
**Manifest:** V3

---

## What Is This Extension?

MasterDesk Access is a browser extension that provides one-click access to premium platforms (e.g., Udemy, ChatGPT/OpenAI) through a shared cookie-based authentication system. Users purchase a plan on [masterdesk.xyz](https://masterdesk.xyz), then use this extension to inject session cookies into their browser and access premium services without needing individual account credentials.

The extension communicates with a backend API at `api.masterdesk.xyz` to fetch cookie data, manage access slots (shared sessions), and ensure only one user occupies a slot at a time via a heartbeat mechanism.

---

## Core Features

| Feature                       | Description                                                                                                                                                                          |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Cookie Injection**          | Receives cookie data from the web app and sets them in the browser via `chrome.cookies` API, then opens the target platform in a new tab.                                            |
| **Slot-Based Access Control** | Each user occupies a "slot" on a platform. The extension tracks active slots and releases them when the session ends or the server revokes access.                                   |
| **Heartbeat System**          | Sends a `PATCH` request to the server every 1 minute per active slot using `chrome.alarms`, proving the user is still online. Survives service worker restarts.                      |
| **Periodic Status Check**     | Every 30 seconds, checks all active slots against the server. If a slot is released (admin reset, plan expired, etc.), cookies are cleared immediately.                              |
| **Instant Slot Release**      | Supports real-time slot release events relayed from the website (via `window.postMessage`). Clears cookies and stops heartbeat without waiting for the next periodic check.          |
| **Automatic Cookie Clearing** | When a slot is released (by server, admin, or expiry), the extension removes all cookies for that platform's domain — preventing continued unauthorized access.                      |
| **Platform UI Hardening**     | Content script hides sensitive UI elements on target platforms (logout buttons, account/security settings, payment methods, delete/archive actions) to prevent shared-account abuse. |
| **Welcome Page**              | Shows a guided onboarding page (`welcome.html`) on first install.                                                                                                                    |

---

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                    masterdesk.xyz                         │
│              (Web App — User Dashboard)                      │
└───────────────┬──────────────────────────────────────────────┘
                │  window.postMessage
                ▼
┌──────────────────────────────────────────────────────────────┐
│  content.js  (Content Script — runs on every page)           │
│  • Bridges messages between web app ↔ background script      │
│  • Announces extension presence to the web page              │
│  • Hides platform UI elements (logout, account, projects)    │
│  • Listens for cookie injection, heartbeat, slot events      │
└───────────────┬──────────────────────────────────────────────┘
                │  chrome.runtime.sendMessage
                ▼
┌──────────────────────────────────────────────────────────────┐
│  background.js  (Service Worker — persistent via alarms)     │
│  • Sets/clears cookies via chrome.cookies API                │
│  • Manages active slots array (in-memory + chrome.storage)   │
│  • Sends heartbeat PATCH requests every 1 min per slot       │
│  • Periodic status check every 30s (checkAllActiveSlots)     │
│  • Handles instant slot release from admin/server events     │
│  • Fetches platform data from API when needed                │
│  • Restores state on service worker restart / browser start  │
└───────────────┬──────────────────────────────────────────────┘
                │  fetch (REST API)
                ▼
┌──────────────────────────────────────────────────────────────┐
│  api.masterdesk.xyz  (Backend API)                        │
│  • GET  /api/slots/:id/status     — check slot active state  │
│  • PATCH /api/slots/:id/heartbeat — keep slot alive          │
│  • GET  /api/cookies/latest       — fetch platform cookies   │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│  popup.html / popup.js  (Extension Popup)                    │
│  • Shows extension status (active/inactive)                  │
│  • Displays number of platforms accessed                     │
│  • "Go to MasterDesk" button → opens dashboard          │
└──────────────────────────────────────────────────────────────┘
```

### File Breakdown

| File            | Role                                                                                                                                                                                                                                |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `manifest.json` | Manifest V3 config — declares permissions (`cookies`, `storage`, `tabs`, `activeTab`, `scripting`, `alarms`), host permissions (`https://*/*`, `http://*/*`), service worker, content scripts, and popup.                           |
| `background.js` | Service worker (1187 lines). Core logic: cookie injection/clearing, heartbeat management, slot status polling, alarm handling, API communication, state persistence via `chrome.storage.local`.                                     |
| `content.js`    | Content script (636 lines). Injected on all pages at `document_start`. Message bridge between web app and background. Hides sensitive UI on Udemy and ChatGPT/OpenAI (logout, account settings, projects, payment, delete actions). |
| `popup.html`    | Extension popup UI — shows status, platform access count, and a link to the dashboard.                                                                                                                                              |
| `popup.js`      | Popup logic — reads `cookieCount` from storage, handles "Go to MasterDesk" button.                                                                                                                                             |
| `welcome.html`  | Onboarding page shown on first install with usage instructions.                                                                                                                                                                     |

### Key Mechanisms

**Heartbeat Flow:**

1. User clicks "Access Platform" on the web app → web app sends `MASTER_TOOLS_START_HEARTBEAT` via `postMessage`.
2. Content script relays to background → `startHeartbeat(slotId, token, domain)`.
3. Background creates a `chrome.alarms` alarm (`heartbeat-{slotId}`) firing every 1 minute.
4. On each alarm, `sendHeartbeat()` sends `PATCH /api/slots/:id/heartbeat` with the auth token.
5. On 400/401 response → slot released → cookies cleared → heartbeat stopped.
6. On 404 → retry up to 3 times, then stop.
7. On network errors → skip, retry on next alarm.

**Cookie Clearing Flow:**

1. Slot release detected (via heartbeat failure, periodic check, or instant event).
2. `clearCookiesForDomain(domain)` normalizes the domain, fetches all cookies for both `domain` and `.domain`, deduplicates, and removes each via `chrome.cookies.remove()`.

**State Persistence:**

- `activeSlots` array is stored in `chrome.storage.local` and restored on service worker wake-up / browser startup.
- Supports migration from older single-slot format to the current multi-slot array format.
- Orphaned alarms (without matching slots) are cleaned up automatically.

---

## Browser Compatibility

| Browser            | Compatible?                              | Notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
| ------------------ | ---------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Google Chrome**  | **Yes**                                  | Primary target. Full Manifest V3 support. All APIs (`chrome.cookies`, `chrome.alarms`, `chrome.scripting`, `chrome.storage`, service worker) work natively.                                                                                                                                                                                                                                                                                                                   |
| **Microsoft Edge** | **Yes**                                  | Chromium-based. Supports Manifest V3 and all `chrome.*` APIs used. Works as-is without modification. Can be sideloaded or published to the Edge Add-ons store.                                                                                                                                                                                                                                                                                                                |
| **Opera**          | **Yes**                                  | Chromium-based. Supports Manifest V3. All APIs used are available. Can be sideloaded or published to the Opera Addons store.                                                                                                                                                                                                                                                                                                                                                  |
| **Brave**          | **Yes**                                  | Chromium-based. Full Manifest V3 and `chrome.*` API support. Works as-is.                                                                                                                                                                                                                                                                                                                                                                                                     |
| **Firefox**        | **No** (not without changes)             | Firefox has Manifest V3 support but with important differences: service workers for extensions have limited support (Firefox still prefers background scripts/pages in some areas), `chrome.cookies.set()` behavior differs, and `chrome.scripting.executeScript` has subtle API differences. The extension exclusively uses `chrome.*` namespace (Firefox uses `browser.*` with a `chrome.*` polyfill, but it's not 100% compatible). **Would require porting and testing.** |
| **Safari**         | **No** (not without significant changes) | Safari supports Web Extensions (Manifest V3) but requires an Xcode project wrapper and has major API limitations: `chrome.cookies` is not fully supported, `chrome.alarms` behavior differs, and `host_permissions` for `*://*/*` may be restricted. **Would require a dedicated Safari Web Extension project.**                                                                                                                                                              |

### Summary

This extension **works out of the box on all Chromium-based browsers** (Chrome, Edge, Opera, Brave, Vivaldi, Arc, etc.). It **will not work on Firefox or Safari** without code modifications and platform-specific adaptations.

---

## Permissions Used

| Permission                  | Why                                                                                         |
| --------------------------- | ------------------------------------------------------------------------------------------- |
| `cookies`                   | Read, set, and remove cookies on target platform domains.                                   |
| `storage`                   | Persist active slot data, cookie count, and heartbeat state across service worker restarts. |
| `tabs`                      | Open new tabs for platform access and the welcome page.                                     |
| `activeTab`                 | Access the current tab for script injection and messaging.                                  |
| `scripting`                 | Inject `content.js` into existing tabs on extension install/update.                         |
| `alarms`                    | Schedule recurring heartbeat pings that survive service worker suspension.                  |
| `https://*/*`, `http://*/*` | Host permissions — required to set cookies and inject content scripts on any domain.        |

---

## Installation (Development / Sideloading)

1. Clone or download this repository.
2. Open `chrome://extensions` (or equivalent in your Chromium browser).
3. Enable **Developer mode**.
4. Click **Load unpacked** and select the extension folder.
5. The welcome page will open automatically on first install.
6. Navigate to [masterdesk.xyz](https://masterdesk.xyz), log in, and access platforms from your dashboard.
