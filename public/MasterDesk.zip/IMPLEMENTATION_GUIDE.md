# Building a Shared-Access Platform (like Master Tools BD)

## Complete Implementation Guide — Express.js + React + Chrome Extension

---

## Table of Contents

1. [System Overview](#1-system-overview)
2. [Database Schema](#2-database-schema)
3. [Backend API (Express.js)](#3-backend-api-expressjs)
4. [Frontend Integration (React)](#4-frontend-integration-react)
5. [Extension Modifications](#5-extension-modifications)
6. [Cookie Collection Strategy](#6-cookie-collection-strategy)
7. [Security Considerations](#7-security-considerations)

---

## 1. System Overview

The system has three components that communicate in a specific chain:

```
┌─────────────┐   postMessage    ┌───────────────┐   chrome.runtime   ┌──────────────┐
│  React App  │ ───────────────► │  content.js   │ ─────────────────► │ background.js│
│  (Frontend) │ ◄─────────────── │  (Extension)  │ ◄───────────────── │  (Extension) │
└──────┬──────┘   postMessage    └───────────────┘   sendResponse     └──────┬───────┘
       │                                                                      │
       │  HTTP (JWT)                                              HTTP (JWT)  │
       ▼                                                                      ▼
┌──────────────────────────────────────────────────────────────────────────────────┐
│                        Express.js Backend API                                    │
│                                                                                  │
│  POST /api/auth/login          →  returns JWT token                              │
│  GET  /api/platforms           →  list available platforms                        │
│  POST /api/slots/acquire       →  reserve a slot (returns slotId + cookies)      │
│  GET  /api/slots/:id/status    →  is this slot still active?                     │
│  PATCH /api/slots/:id/heartbeat →  "I'm still here" ping                        │
│  POST /api/slots/:id/release   →  user manually releases slot                   │
│  GET  /api/cookies/latest      →  fetch cookies for a platform                   │
└──────────────────────────────────────────────────────────────────────────────────┘
```

### How it works (end-to-end flow):

1. **Admin** logs into a premium platform (e.g., Udemy), exports the session cookies, and uploads them to the backend.
2. **User** logs into your React app, sees available platforms on their dashboard.
3. **User** clicks "Access Platform" → React app sends a `postMessage` to the extension.
4. **Extension** receives cookies from the backend API, injects them into the browser via `chrome.cookies.set()`, and opens the target platform in a new tab.
5. **Extension** starts sending heartbeat pings every 1 minute to keep the slot reserved.
6. **Backend** marks the slot as occupied. If heartbeats stop (user closes browser), the slot is released after ~3 missed beats.
7. **Extension** periodically checks slot status (every 30s). If the slot is released (admin reset, expiry, etc.), it clears cookies immediately.

---

## 2. Database Schema

You need at minimum these models. Below are Mongoose schemas (MongoDB), but adapt to your DB.

### 2.1 User

```js
// models/User.js
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const userSchema = new mongoose.Schema({
	email: { type: String, required: true, unique: true },
	password: { type: String, required: true },
	name: { type: String },
	plan: { type: mongoose.Schema.Types.ObjectId, ref: "Plan" },
	planExpiry: { type: Date },
	isActive: { type: Boolean, default: true },
	createdAt: { type: Date, default: Date.now },
});

userSchema.pre("save", async function (next) {
	if (!this.isModified("password")) return next();
	this.password = await bcrypt.hash(this.password, 12);
	next();
});

userSchema.methods.comparePassword = async function (candidatePassword) {
	return bcrypt.compare(candidatePassword, this.password);
};

module.exports = mongoose.model("User", userSchema);
```

### 2.2 Plan

```js
// models/Plan.js
const planSchema = new mongoose.Schema({
	name: { type: String, required: true }, // "Basic", "Premium"
	price: { type: Number, required: true },
	duration: { type: Number, required: true }, // days
	platforms: [{ type: mongoose.Schema.Types.ObjectId, ref: "Platform" }], // which platforms this plan includes
	maxSlots: { type: Number, default: 1 }, // how many platforms user can access simultaneously
	isActive: { type: Boolean, default: true },
	createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Plan", planSchema);
```

### 2.3 Platform

```js
// models/Platform.js
const platformSchema = new mongoose.Schema({
	name: { type: String, required: true, unique: true }, // "chatgpt", "udemy", "canva"
	displayName: { type: String, required: true }, // "ChatGPT Plus"
	domain: { type: String, required: true }, // "chatgpt.com"
	redirect: { type: String }, // URL to open after cookie injection
	icon: { type: String }, // URL to platform icon
	maxSlots: { type: Number, default: 3 }, // max concurrent users on this platform
	isActive: { type: Boolean, default: true },
	createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Platform", platformSchema);
```

### 2.4 Cookie (stored cookies for each platform)

```js
// models/Cookie.js
const cookieSchema = new mongoose.Schema({
	platform: {
		type: mongoose.Schema.Types.ObjectId,
		ref: "Platform",
		required: true,
	},
	domain: { type: String, required: true }, // e.g. ".chatgpt.com"
	cookies: [
		{
			// array of cookie objects
			name: { type: String, required: true },
			value: { type: String, required: true },
			domain: { type: String }, // e.g. ".chatgpt.com"
			path: { type: String, default: "/" },
			secure: { type: Boolean, default: true },
			httpOnly: { type: Boolean, default: false },
			sameSite: { type: String, default: "no_restriction" },
			expirationDate: { type: Number },
			session: { type: Boolean, default: false },
		},
	],
	isValid: { type: Boolean, default: true }, // becomes false when cookies expire
	uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // admin who uploaded
	createdAt: { type: Date, default: Date.now },
	expiresAt: { type: Date },
});

module.exports = mongoose.model("Cookie", cookieSchema);
```

### 2.5 Slot (tracks who is currently using which platform)

```js
// models/Slot.js
const slotSchema = new mongoose.Schema({
	platform: {
		type: mongoose.Schema.Types.ObjectId,
		ref: "Platform",
		required: true,
	},
	user: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
	isActive: { type: Boolean, default: false }, // true = someone is using it
	lastHeartbeat: { type: Date, default: null }, // last heartbeat received
	domain: { type: String }, // cookie domain (for extension cookie clearing)
	platformId: { type: String }, // platform identifier string
	assignedAt: { type: Date, default: null },
	createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model("Slot", slotSchema);
```

---

## 3. Backend API (Express.js)

### 3.1 Project Structure

```
backend/
├── server.js
├── config/
│   └── db.js
├── middleware/
│   └── auth.js                 # JWT verification middleware
├── models/
│   ├── User.js
│   ├── Plan.js
│   ├── Platform.js
│   ├── Cookie.js
│   └── Slot.js
├── routes/
│   ├── auth.js                 # POST /api/auth/login, /register
│   ├── platforms.js            # GET /api/platforms
│   ├── slots.js                # slot acquire/release/status/heartbeat
│   ├── cookies.js              # GET /api/cookies/latest
│   └── admin.js                # admin: upload cookies, manage platforms
├── jobs/
│   └── heartbeatChecker.js     # cron job to release stale slots
└── package.json
```

### 3.2 Auth Middleware

```js
// middleware/auth.js
const jwt = require("jsonwebtoken");
const User = require("../models/User");

module.exports = async (req, res, next) => {
	try {
		const authHeader = req.headers.authorization;
		if (!authHeader || !authHeader.startsWith("Bearer ")) {
			return res.status(401).json({ error: "No token provided" });
		}

		const token = authHeader.split(" ")[1];
		const decoded = jwt.verify(token, process.env.JWT_SECRET);

		const user = await User.findById(decoded.userId).populate("plan");
		if (!user || !user.isActive) {
			return res
				.status(401)
				.json({ error: "User not found or inactive" });
		}

		// Check plan expiry
		if (user.planExpiry && new Date() > user.planExpiry) {
			return res.status(401).json({ error: "Plan expired" });
		}

		req.user = user;
		next();
	} catch (error) {
		return res.status(401).json({ error: "Invalid token" });
	}
};
```

### 3.3 Auth Routes

```js
// routes/auth.js
const router = require("express").Router();
const jwt = require("jsonwebtoken");
const User = require("../models/User");

// POST /api/auth/login
router.post("/login", async (req, res) => {
	try {
		const { email, password } = req.body;

		const user = await User.findOne({ email }).populate("plan");
		if (!user || !(await user.comparePassword(password))) {
			return res.status(401).json({ error: "Invalid credentials" });
		}

		const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
			expiresIn: "7d",
		});

		res.json({
			token,
			user: { id: user._id, email: user.email, name: user.name },
		});
	} catch (error) {
		res.status(500).json({ error: "Server error" });
	}
});

module.exports = router;
```

### 3.4 Slot Routes (CRITICAL — these are what the extension calls)

```js
// routes/slots.js
const router = require("express").Router();
const auth = require("../middleware/auth");
const Slot = require("../models/Slot");
const Cookie = require("../models/Cookie");
const Platform = require("../models/Platform");

// ─────────────────────────────────────────────────────
// POST /api/slots/acquire
// Called by React frontend when user clicks "Access Platform"
// Finds a free slot, assigns user, returns slotId + cookies
// ─────────────────────────────────────────────────────
router.post("/acquire", auth, async (req, res) => {
	try {
		const { platformId } = req.body;
		const platform = await Platform.findById(platformId);
		if (!platform)
			return res.status(404).json({ error: "Platform not found" });

		// Check if user's plan includes this platform
		if (!req.user.plan || !req.user.plan.platforms.includes(platform._id)) {
			return res.status(403).json({ error: "Platform not in your plan" });
		}

		// Find a free slot (not active or heartbeat expired)
		const HEARTBEAT_TIMEOUT = 3 * 60 * 1000; // 3 minutes
		let slot = await Slot.findOne({
			platform: platform._id,
			$or: [
				{ isActive: false },
				{
					lastHeartbeat: {
						$lt: new Date(Date.now() - HEARTBEAT_TIMEOUT),
					},
				},
			],
		});

		// If no free slot exists and we haven't hit max, create one
		if (!slot) {
			const slotCount = await Slot.countDocuments({
				platform: platform._id,
				isActive: true,
			});
			if (slotCount >= platform.maxSlots) {
				return res
					.status(429)
					.json({
						error: "All slots are occupied. Try again later.",
					});
			}
			slot = new Slot({ platform: platform._id });
		}

		// Assign slot to user
		slot.user = req.user._id;
		slot.isActive = true;
		slot.lastHeartbeat = new Date();
		slot.domain = platform.domain;
		slot.platformId = platform.name;
		slot.assignedAt = new Date();
		await slot.save();

		// Fetch latest valid cookies for this platform
		const cookieDoc = await Cookie.findOne({
			platform: platform._id,
			isValid: true,
		}).sort({ createdAt: -1 });

		if (!cookieDoc) {
			// Release slot if no cookies available
			slot.isActive = false;
			slot.user = null;
			await slot.save();
			return res
				.status(404)
				.json({
					error: "No valid cookies available for this platform",
				});
		}

		res.json({
			slotId: slot._id.toString(),
			domain: cookieDoc.domain,
			redirect: platform.redirect || `https://${platform.domain}`,
			cookies: cookieDoc.cookies,
			platformId: platform.name,
		});
	} catch (error) {
		console.error("Slot acquire error:", error);
		res.status(500).json({ error: "Server error" });
	}
});

// ─────────────────────────────────────────────────────
// GET /api/slots/:slotId/status
// Extension calls this every 30s to check if slot is still valid
// Response: { isActive: boolean, domain: string|null }
// ─────────────────────────────────────────────────────
router.get("/:slotId/status", auth, async (req, res) => {
	try {
		const slot = await Slot.findById(req.params.slotId).populate(
			"platform",
		);
		if (!slot) {
			return res
				.status(404)
				.json({
					isActive: false,
					error: "Slot not found",
					domain: null,
				});
		}

		// Verify the requesting user owns this slot
		if (slot.user && slot.user.toString() !== req.user._id.toString()) {
			return res
				.status(401)
				.json({ isActive: false, error: "Unauthorized", domain: null });
		}

		res.json({
			isActive: slot.isActive,
			domain: slot.domain,
			slotId: slot._id.toString(),
			platformId: slot.platformId,
		});
	} catch (error) {
		res.status(500).json({
			isActive: false,
			error: "Server error",
			domain: null,
		});
	}
});

// ─────────────────────────────────────────────────────
// PATCH /api/slots/:slotId/heartbeat
// Extension calls this every 1 minute to keep the slot alive
// 200 = alive, 400 = user not using, 401 = unauthorized, 404 = not found
// ─────────────────────────────────────────────────────
router.patch("/:slotId/heartbeat", auth, async (req, res) => {
	try {
		const slot = await Slot.findById(req.params.slotId);
		if (!slot) {
			return res.status(404).json({ error: "Slot not found" });
		}

		// Verify ownership
		if (!slot.user || slot.user.toString() !== req.user._id.toString()) {
			return res.status(401).json({ error: "Unauthorized" });
		}

		// Check if slot is still active
		if (!slot.isActive) {
			return res.status(400).json({ error: "Slot is no longer active" });
		}

		// Update heartbeat timestamp
		slot.lastHeartbeat = new Date();
		await slot.save();

		res.json({ success: true, slotId: slot._id.toString() });
	} catch (error) {
		res.status(500).json({ error: "Server error" });
	}
});

// ─────────────────────────────────────────────────────
// POST /api/slots/:slotId/release
// User or admin manually releases a slot
// ─────────────────────────────────────────────────────
router.post("/:slotId/release", auth, async (req, res) => {
	try {
		const slot = await Slot.findById(req.params.slotId);
		if (!slot) return res.status(404).json({ error: "Slot not found" });

		slot.isActive = false;
		slot.user = null;
		slot.lastHeartbeat = null;
		slot.assignedAt = null;
		await slot.save();

		res.json({ success: true });
	} catch (error) {
		res.status(500).json({ error: "Server error" });
	}
});

module.exports = router;
```

### 3.5 Cookies Route

```js
// routes/cookies.js
const router = require("express").Router();
const auth = require("../middleware/auth");
const Cookie = require("../models/Cookie");
const Platform = require("../models/Platform");

// ─────────────────────────────────────────────────────
// GET /api/cookies/latest?platform=chatgpt
// Extension calls this to get cookie data for injection
// Response: { domain, redirect, cookies: [...] }
// ─────────────────────────────────────────────────────
router.get("/latest", auth, async (req, res) => {
	try {
		const { platform: platformName } = req.query;
		if (!platformName) {
			return res.status(400).json({ error: "Platform name required" });
		}

		const platform = await Platform.findOne({ name: platformName });
		if (!platform) {
			return res.status(404).json({ error: "Platform not found" });
		}

		// Check user plan includes this platform
		if (!req.user.plan || !req.user.plan.platforms.includes(platform._id)) {
			return res.status(403).json({ error: "Platform not in your plan" });
		}

		const cookieDoc = await Cookie.findOne({
			platform: platform._id,
			isValid: true,
		}).sort({ createdAt: -1 });

		if (!cookieDoc) {
			return res
				.status(404)
				.json({ error: "No valid cookies available" });
		}

		res.json({
			domain: cookieDoc.domain,
			redirect: platform.redirect || `https://${platform.domain}`,
			cookies: cookieDoc.cookies,
		});
	} catch (error) {
		res.status(500).json({ error: "Server error" });
	}
});

module.exports = router;
```

### 3.6 Admin Routes (upload cookies)

```js
// routes/admin.js
const router = require("express").Router();
const auth = require("../middleware/auth");
const Cookie = require("../models/Cookie");
const Platform = require("../models/Platform");

// Admin middleware (add role check to your User model)
const adminOnly = (req, res, next) => {
	if (!req.user.isAdmin) return res.status(403).json({ error: "Admin only" });
	next();
};

// ─────────────────────────────────────────────────────
// POST /api/admin/cookies/upload
// Admin uploads cookies for a platform (JSON array from browser cookie editor)
// ─────────────────────────────────────────────────────
router.post("/cookies/upload", auth, adminOnly, async (req, res) => {
	try {
		const { platformId, cookies, domain } = req.body;

		const platform = await Platform.findById(platformId);
		if (!platform)
			return res.status(404).json({ error: "Platform not found" });

		// Invalidate old cookies for this platform
		await Cookie.updateMany(
			{ platform: platform._id, isValid: true },
			{ isValid: false },
		);

		// Save new cookies
		const cookieDoc = new Cookie({
			platform: platform._id,
			domain: domain || platform.domain,
			cookies: cookies, // array of { name, value, domain, path, secure, httpOnly, sameSite }
			isValid: true,
			uploadedBy: req.user._id,
			expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days default
		});
		await cookieDoc.save();

		res.json({ success: true, cookieId: cookieDoc._id });
	} catch (error) {
		res.status(500).json({ error: "Server error" });
	}
});

// POST /api/admin/slots/:slotId/reset  — force release a slot
router.post("/slots/:slotId/reset", auth, adminOnly, async (req, res) => {
	const Slot = require("../models/Slot");
	const slot = await Slot.findById(req.params.slotId);
	if (!slot) return res.status(404).json({ error: "Slot not found" });

	slot.isActive = false;
	slot.user = null;
	slot.lastHeartbeat = null;
	await slot.save();

	// Optional: emit socket event for instant release (see section 3.8)
	// io.emit('slot-released', { slotId: slot._id, reason: 'admin_reset' });

	res.json({ success: true });
});

module.exports = router;
```

### 3.7 Heartbeat Checker Cron Job

```js
// jobs/heartbeatChecker.js
const cron = require("node-cron");
const Slot = require("../models/Slot");

const HEARTBEAT_TIMEOUT = 3 * 60 * 1000; // 3 minutes (3 missed beats)

function startHeartbeatChecker() {
	// Run every minute
	cron.schedule("* * * * *", async () => {
		try {
			const staleSlots = await Slot.find({
				isActive: true,
				lastHeartbeat: {
					$lt: new Date(Date.now() - HEARTBEAT_TIMEOUT),
				},
			});

			for (const slot of staleSlots) {
				console.log(
					`Releasing stale slot: ${slot._id} (last heartbeat: ${slot.lastHeartbeat})`,
				);
				slot.isActive = false;
				slot.user = null;
				slot.lastHeartbeat = null;
				slot.assignedAt = null;
				await slot.save();
			}

			if (staleSlots.length > 0) {
				console.log(`Released ${staleSlots.length} stale slot(s)`);
			}
		} catch (error) {
			console.error("Heartbeat checker error:", error);
		}
	});

	console.log("Heartbeat checker started (runs every minute)");
}

module.exports = startHeartbeatChecker;
```

### 3.8 Server Entry Point

```js
// server.js
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
require("dotenv").config();

const app = express();

// CORS — allow your React app and extension origins
app.use(
	cors({
		origin: [
			"http://localhost:3000", // React dev
			"http://localhost:5173", // Vite dev
			"https://yourdomain.com", // Production frontend
		],
		credentials: false, // extension uses credentials: 'omit'
	}),
);

app.use(express.json({ limit: "10mb" })); // cookies payloads can be large

// Routes
app.use("/api/auth", require("./routes/auth"));
app.use("/api/platforms", require("./routes/platforms"));
app.use("/api/slots", require("./routes/slots"));
app.use("/api/cookies", require("./routes/cookies"));
app.use("/api/admin", require("./routes/admin"));

// Connect DB and start
mongoose.connect(process.env.MONGODB_URI).then(() => {
	console.log("MongoDB connected");

	// Start heartbeat checker cron job
	const startHeartbeatChecker = require("./jobs/heartbeatChecker");
	startHeartbeatChecker();

	app.listen(process.env.PORT || 5000, () => {
		console.log(`Server running on port ${process.env.PORT || 5000}`);
	});
});
```

---

## 4. Frontend Integration (React)

### 4.1 Extension Detection Hook

The React app must communicate with the extension via `window.postMessage`. The content script listens for messages from your domain only.

```jsx
// hooks/useExtension.js
import { useState, useEffect, useCallback } from "react";

export function useExtension() {
	const [extensionInstalled, setExtensionInstalled] = useState(false);
	const [extensionVersion, setExtensionVersion] = useState(null);

	useEffect(() => {
		// Listen for extension responses
		const handler = (event) => {
			if (event.data?.type === "MASTER_TOOLS_EXTENSION_PRESENT") {
				setExtensionInstalled(true);
				setExtensionVersion(event.data.version || "unknown");
			}
		};
		window.addEventListener("message", handler);

		// Ask extension if it's installed
		window.postMessage({ type: "MASTER_TOOLS_CHECK_EXTENSION" }, "*");

		return () => window.removeEventListener("message", handler);
	}, []);

	return { extensionInstalled, extensionVersion };
}
```

### 4.2 Platform Access Function

This is the core function your dashboard calls when the user clicks "Access Platform":

```jsx
// services/platformAccess.js
import api from "./api"; // your axios instance with JWT interceptor

export async function accessPlatform(platformId, platformName) {
	// Step 1: Acquire a slot from your backend
	const { data } = await api.post("/api/slots/acquire", { platformId });
	// data = { slotId, domain, redirect, cookies, platformId }

	// Step 2: Send cookies to extension for injection
	//         Uses the ACCESS message type (new API path)
	window.postMessage(
		{
			type: "MASTER_TOOLS_ACCESS_PLATFORM",
			payload: {
				platform: platformName,
				token: localStorage.getItem("token"), // JWT
				platformData: {
					domain: data.domain,
					redirect: data.redirect,
					cookies: data.cookies,
				},
			},
		},
		"*",
	);

	// Step 3: Start heartbeat in extension
	//         This keeps the slot alive as long as the user's browser is open
	window.postMessage(
		{
			type: "MASTER_TOOLS_START_HEARTBEAT",
			payload: {
				slotId: data.slotId,
				token: localStorage.getItem("token"),
				domain: data.domain,
				platformId: data.platformId,
			},
		},
		"*",
	);

	return data;
}
```

### 4.3 Release Slot (when user manually disconnects)

```jsx
// services/platformAccess.js (continued)

export function releaseSlot(
	slotId,
	platformId,
	planId,
	reason = "user_release",
) {
	// Tell extension to stop heartbeat and clear cookies
	window.postMessage(
		{
			type: "MASTER_TOOLS_SLOT_RELEASED",
			payload: { slotId, platformId, planId, reason },
		},
		"*",
	);

	// Also tell your backend
	api.post(`/api/slots/${slotId}/release`);
}

export function stopHeartbeat() {
	window.postMessage({ type: "MASTER_TOOLS_STOP_HEARTBEAT" }, "*");
}
```

### 4.4 Listen for Extension Results

```jsx
// hooks/useExtensionMessages.js
import { useEffect } from "react";

export function useExtensionMessages({ onAccessResult, onCookieStatus }) {
	useEffect(() => {
		const handler = (event) => {
			switch (event.data?.type) {
				case "MASTER_TOOLS_PLATFORM_ACCESS_RESULT":
					onAccessResult?.(event.data); // { success, error }
					break;

				case "MASTER_TOOLS_COOKIES_STATUS":
					onCookieStatus?.(event.data); // { status: "Accessing platform..." }
					break;

				case "MASTER_TOOLS_COOKIES_RESULT":
					onAccessResult?.(event.data); // { success, error }
					break;
			}
		};

		window.addEventListener("message", handler);
		return () => window.removeEventListener("message", handler);
	}, [onAccessResult, onCookieStatus]);
}
```

### 4.5 Dashboard Component Example

```jsx
// pages/Dashboard.jsx
import React, { useState, useEffect } from "react";
import { useExtension } from "../hooks/useExtension";
import { useExtensionMessages } from "../hooks/useExtensionMessages";
import { accessPlatform, releaseSlot } from "../services/platformAccess";
import api from "../services/api";

export default function Dashboard() {
	const { extensionInstalled } = useExtension();
	const [platforms, setPlatforms] = useState([]);
	const [loading, setLoading] = useState(null); // platformId being loaded
	const [activeSlots, setActiveSlots] = useState({}); // { platformId: slotId }

	useExtensionMessages({
		onAccessResult: (data) => {
			setLoading(null);
			if (!data.success) alert(`Access failed: ${data.error}`);
		},
		onCookieStatus: (data) => {
			console.log("Status:", data.status);
		},
	});

	useEffect(() => {
		api.get("/api/platforms").then((res) => setPlatforms(res.data));
	}, []);

	const handleAccess = async (platform) => {
		if (!extensionInstalled) {
			alert("Please install the browser extension first!");
			return;
		}
		setLoading(platform._id);
		try {
			const data = await accessPlatform(platform._id, platform.name);
			setActiveSlots((prev) => ({
				...prev,
				[platform._id]: data.slotId,
			}));
		} catch (err) {
			setLoading(null);
			alert(err.response?.data?.error || "Failed to access platform");
		}
	};

	const handleRelease = (platform) => {
		const slotId = activeSlots[platform._id];
		if (slotId) {
			releaseSlot(slotId, platform._id);
			setActiveSlots((prev) => {
				const n = { ...prev };
				delete n[platform._id];
				return n;
			});
		}
	};

	return (
		<div>
			<h1>Dashboard</h1>
			{!extensionInstalled && (
				<div className="alert">
					⚠️ Extension not detected.{" "}
					<a href="/extension">Install it here</a>.
				</div>
			)}
			<div className="platform-grid">
				{platforms.map((p) => (
					<div key={p._id} className="platform-card">
						<h3>{p.displayName}</h3>
						{activeSlots[p._id] ? (
							<button onClick={() => handleRelease(p)}>
								Disconnect
							</button>
						) : (
							<button
								onClick={() => handleAccess(p)}
								disabled={
									loading === p._id || !extensionInstalled
								}
							>
								{loading === p._id
									? "Connecting..."
									: `Access ${p.displayName} Now`}
							</button>
						)}
					</div>
				))}
			</div>
		</div>
	);
}
```

---

## 5. Extension Modifications

You need to change **3 things** in the extension to make it work with your own domain:

### 5.1 `background.js` — Change API URL

```js
// Line 8: Change the API base URL to your backend
const API_BASE_URL = "https://api.yourdomain.com";
```

### 5.2 `content.js` — Allow your domain in the origin check

```js
// Line ~34: Update the origin check to include your domain
if (
	!(
		event.origin.includes("yourdomain.com") || // ← your production domain
		event.origin.includes("localhost") ||
		event.data?.type === "MASTER_TOOLS_CHECK_EXTENSION"
	)
) {
	return;
}
```

### 5.3 `popup.js` — Update website URL

```js
const websiteUrl = "https://yourdomain.com";
```

### 5.4 `welcome.html` — Update dashboard link

```html
<a href="https://yourdomain.com/dashboard" class="btn">Go to My Dashboard</a>
```

### 5.5 `manifest.json` — Update name and description

```json
{
	"name": "Your App Name",
	"description": "Your description here"
}
```

---

## 6. Cookie Collection Strategy

The admin needs to obtain valid session cookies from premium platforms. Here's the workflow:

### Method: Manual Cookie Export

1. Admin logs into the premium platform (e.g., Udemy with a real paid account).
2. Uses a browser extension like **Cookie-Editor** or **EditThisCookie** to export all cookies as JSON.
3. Uploads the JSON to your backend via the admin panel (`POST /api/admin/cookies/upload`).

### Expected Cookie JSON Format

The extension expects cookies in this shape (from `processPlatformData` in background.js):

```json
[
	{
		"name": "__Secure-next-auth.session-token",
		"value": "eyJhbGciOi...",
		"domain": ".chatgpt.com",
		"path": "/",
		"secure": true,
		"httpOnly": false,
		"sameSite": "no_restriction"
	},
	{
		"name": "_ga",
		"value": "GA1.2.123456789",
		"domain": ".chatgpt.com",
		"path": "/"
	}
]
```

The extension applies these defaults when injecting:

- `secure` → defaults to `true`
- `httpOnly` → forced to `false` (otherwise `chrome.cookies.set` can't set it in some cases)
- `sameSite` → defaults to `"no_restriction"`
- `expirationDate` → defaults to now + 30 days
- `session` → defaults to `false`

---

## 7. Security Considerations

| Area                            | What to Implement                                                                                                      |
| ------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| **JWT Expiry**                  | Use short-lived tokens (e.g., 7 days). The extension stores the token per slot.                                        |
| **Rate Limiting**               | Rate-limithea rtbeat and status endpoints (e.g., max 2 req/min per slot).                                              |
| **Slot Ownership**              | Always verify `slot.user === req.user._id` on heartbeat/status. The code above does this.                              |
| **Cookie Encryption**           | Store cookies encrypted at rest in the database. Decrypt only when serving to authenticated users.                     |
| **CORS**                        | Only allow your frontend domain. The extension uses `credentials: 'omit'` and `mode: 'cors'`.                          |
| **HTTPS**                       | Mandatory in production. Cookies with `secure: true` won't work over HTTP.                                             |
| **Plan Validation**             | Check plan expiry and platform access on every slot acquire and cookie fetch.                                          |
| **Admin Auth**                  | Separate admin role. Only admins can upload cookies or reset slots.                                                    |
| **Content Script Origin Check** | The `content.js` origin filter prevents other websites from sending commands to the extension.                         |
| **UI Hiding**                   | The content script hides logout/account/security UI on target platforms. Customize for your platforms in `content.js`. |

---

## Quick Checklist

- [ ] Set up MongoDB with the 5 models (User, Plan, Platform, Cookie, Slot)
- [ ] Implement the 6 API endpoints (login, platforms, slot acquire/status/heartbeat/release, cookies/latest)
- [ ] Implement the admin cookie upload endpoint
- [ ] Set up the heartbeat checker cron job (releases stale slots every minute)
- [ ] In React: add extension detection hook, platform access function, and postMessage listeners
- [ ] In the extension: update `API_BASE_URL`, origin check domain, popup URL, and manifest metadata
- [ ] Test the full flow: login → access platform → cookie injection → heartbeat → slot release
- [ ] Deploy backend with HTTPS, configure CORS for your frontend domain
